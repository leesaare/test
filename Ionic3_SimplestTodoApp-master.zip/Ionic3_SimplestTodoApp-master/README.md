## Ionic3_SimplesTodoApp
Simplest todo application using the ever so slightly awesome Ionic 3

## Tutorial
Short tutorial on how to create this your self is here: [How to create the simplest TODO application with Ionic 3](http://www.nikola-breznjak.com/blog/javascript/ionic3/create-simplest-todo-application-ionic-3/).

## Screenshot
![](http://i.imgur.com/yf78Fnr.png)